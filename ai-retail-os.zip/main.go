package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"strconv"
	"strings"

	_ "modernc.org/sqlite"
)

type App struct{ db *sql.DB }
type Product struct {
	ID int64 `json:"id"`
	Name string `json:"name"`
	Category string `json:"category"`
	Price float64 `json:"price"`
	Stock int `json:"stock"`
}
type SaleRequest struct {
	ProductID int64 `json:"product_id"`
	Quantity int `json:"quantity"`
}

func main() {
	db, err := sql.Open("sqlite", "retail.db")
	if err != nil { log.Fatal(err) }
	defer db.Close()
	db.SetMaxOpenConns(1)
	if err := initDB(db); err != nil { log.Fatal(err) }
	app := &App{db: db}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /health", app.health)
	mux.HandleFunc("GET /products", app.listProducts)
	mux.HandleFunc("POST /products", app.createProduct)
	mux.HandleFunc("POST /sales", app.recordSale)
	mux.HandleFunc("GET /dashboard", app.dashboard)
	log.Println("AI Retail OS API running at http://localhost:8081")
	log.Fatal(http.ListenAndServe(":8081", mux))
}

func initDB(db *sql.DB) error {
	qs := []string{
		`CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL, price REAL NOT NULL CHECK(price>=0), stock INTEGER NOT NULL CHECK(stock>=0), units_sold INTEGER NOT NULL DEFAULT 0)`,
	}
	for _, q := range qs { if _, err := db.Exec(q); err != nil { return err } }
	var count int
	if err := db.QueryRow("SELECT COUNT(*) FROM products").Scan(&count); err != nil { return err }
	if count == 0 {
		_, err := db.Exec(`INSERT INTO products(name,category,price,stock,units_sold) VALUES
			('Coffee','Grocery',180,40,120),('Notebook','Stationery',60,50,85),
			('Headphones','Electronics',1250,12,32),('Water Bottle','Accessories',250,24,64)`)
		return err
	}
	return nil
}
func (a *App) health(w http.ResponseWriter, r *http.Request) { jsonOut(w,200,map[string]string{"status":"ok"}) }
func (a *App) listProducts(w http.ResponseWriter, r *http.Request) {
	rows,err:=a.db.Query("SELECT id,name,category,price,stock FROM products ORDER BY id")
	if err!=nil { internalError(w,err); return }; defer rows.Close()
	products:=[]Product{}
	for rows.Next() { var p Product; if err:=rows.Scan(&p.ID,&p.Name,&p.Category,&p.Price,&p.Stock); err!=nil { internalError(w,err); return }; products=append(products,p) }
	jsonOut(w,200,products)
}
func (a *App) createProduct(w http.ResponseWriter, r *http.Request) {
	var p Product
	if err:=json.NewDecoder(r.Body).Decode(&p); err!=nil { jsonErr(w,400,"Invalid JSON body"); return }
	p.Name=strings.TrimSpace(p.Name); p.Category=strings.TrimSpace(p.Category)
	if p.Name=="" || p.Category=="" || p.Price<0 || p.Stock<0 { jsonErr(w,400,"name/category required; price and stock must be non-negative"); return }
	res,err:=a.db.Exec("INSERT INTO products(name,category,price,stock) VALUES(?,?,?,?)",p.Name,p.Category,p.Price,p.Stock)
	if err!=nil { internalError(w,err); return }; p.ID,_=res.LastInsertId()
	jsonOut(w,201,p)
}
func (a *App) recordSale(w http.ResponseWriter, r *http.Request) {
	var req SaleRequest
	if err:=json.NewDecoder(r.Body).Decode(&req); err!=nil { jsonErr(w,400,"Invalid JSON body"); return }
	if req.ProductID<1 || req.Quantity<1 || req.Quantity>10000 { jsonErr(w,400,"product_id and quantity must be positive; quantity maximum is 10000"); return }
	tx,err:=a.db.Begin(); if err!=nil { internalError(w,err); return }; defer tx.Rollback()
	var stock int
	err=tx.QueryRow("SELECT stock FROM products WHERE id=?",req.ProductID).Scan(&stock)
	if errors.Is(err,sql.ErrNoRows) { jsonErr(w,404,"Product not found"); return }
	if err!=nil { internalError(w,err); return }
	if req.Quantity>stock { jsonErr(w,409,"Not enough stock"); return }
	_,err=tx.Exec("UPDATE products SET stock=stock-?, units_sold=units_sold+? WHERE id=?",req.Quantity,req.Quantity,req.ProductID)
	if err!=nil { internalError(w,err); return }
	if err=tx.Commit(); err!=nil { internalError(w,err); return }
	jsonOut(w,200,map[string]string{"message":"Sale recorded","status":"success"})
}
func (a *App) dashboard(w http.ResponseWriter, r *http.Request) {
	var products, units int
	var revenue float64
	if err:=a.db.QueryRow("SELECT COUNT(*),COALESCE(SUM(units_sold),0),COALESCE(SUM(units_sold*price),0) FROM products").Scan(&products,&units,&revenue); err!=nil { internalError(w,err); return }
	var topName string; var topUnits int
	err:=a.db.QueryRow("SELECT name,units_sold FROM products ORDER BY units_sold DESC,name ASC LIMIT 1").Scan(&topName,&topUnits)
	if err!=nil && !errors.Is(err,sql.ErrNoRows) { internalError(w,err); return }
	jsonOut(w,200,map[string]any{
		"product_count":products,
		"total_units_sold":units,
		"estimated_revenue":revenue,
		"best_seller":map[string]any{"product":topName,"units_sold":topUnits},
		"note":"Descriptive summary based on stored sample sales; no predictive AI model is connected."
	})
}
func jsonOut(w http.ResponseWriter,status int,v any) { w.Header().Set("Content-Type","application/json"); w.WriteHeader(status); _=json.NewEncoder(w).Encode(v) }
func jsonErr(w http.ResponseWriter,status int,msg string) { jsonOut(w,status,map[string]string{"error":msg}) }
func internalError(w http.ResponseWriter,err error) { log.Println(err); jsonErr(w,500,"Internal server error") }

// Keep strconv imported as a small example of safe path/query parsing for future extensions.
var _ = strconv.Atoi
