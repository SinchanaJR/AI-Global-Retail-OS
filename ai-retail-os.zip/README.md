# AI Retail OS — Retail Operations API

A runnable Go + SQLite backend prototype for retail operations. It tracks products, stock levels, and sales; provides inventory KPIs and a descriptive best-seller insight.

## Requirements
- Go 1.22 or newer
- Internet access the first time Go downloads the SQLite driver

## Run locally
```bash
go mod tidy
go run .
```
The API starts at `http://localhost:8081`. SQLite creates `retail.db` automatically.

## Endpoints
- `GET /health`
- `GET /products`
- `POST /products`
- `POST /sales`
- `GET /dashboard`

## Example
Add a product:
```bash
curl -X POST http://localhost:8081/products -H "Content-Type: application/json" -d "{\"name\":\"Green Tea\",\"category\":\"Grocery\",\"price\":220,\"stock\":25}"
```
Record a sale (use an existing product ID):
```bash
curl -X POST http://localhost:8081/sales -H "Content-Type: application/json" -d "{\"product_id\":1,\"quantity\":2}"
```
View dashboard:
```bash
curl http://localhost:8081/dashboard
```

## Important
The dashboard uses sample data and descriptive calculations. It does not contain a predictive AI model yet. This is a backend learning prototype, not a production inventory system.
